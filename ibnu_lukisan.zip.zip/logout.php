<?php
// logout.php
session_start();  // mulai session
session_destroy(); // hapus semua session
header("Location: login.php"); // redirect ke login
exit;
