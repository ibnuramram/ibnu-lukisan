<?php
session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int)$_GET['id'];

$error = '';
$success = '';

// Ambil data item
$stmt = $pdo->prepare("SELECT * FROM items WHERE id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    header("Location: index.php");
    exit;
}

// Ambil deskripsi
$stmtDesc = $pdo->prepare("SELECT content FROM description WHERE item_id = ?");
$stmtDesc->execute([$id]);
$descData = $stmtDesc->fetch();
$description = $descData ? $descData['content'] : "";

// Ambil nama asal dan periode
$origin_name = '';
$period_name = '';
$stmt = $pdo->prepare("SELECT origin_name FROM origins WHERE id = ?");
$stmt->execute([$item['origin_id']]);
$originRow = $stmt->fetch();
$origin_name = $originRow ? $originRow['origin_name'] : '';

$stmt = $pdo->prepare("SELECT period_name FROM periods WHERE id = ?");
$stmt->execute([$item['period_id']]);
$periodRow = $stmt->fetch();
$period_name = $periodRow ? $periodRow['period_name'] : '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $origin_name = trim($_POST['origin_name']);
    $period_name = trim($_POST['period_name']);
    $description = trim($_POST['description']);

    if ($name == '' || $origin_name == '' || $period_name == '') {
        $error = "Nama, asal, dan periode wajib diisi!";
    } else {
        // Cek atau tambah asal
        $stmt = $pdo->prepare("SELECT id FROM origins WHERE origin_name = ?");
        $stmt->execute([$origin_name]);
        $origin = $stmt->fetch();
        if ($origin) {
            $origin_id = $origin['id'];
        } else {
            $stmt = $pdo->prepare("INSERT INTO origins (origin_name) VALUES (?)");
            $stmt->execute([$origin_name]);
            $origin_id = $pdo->lastInsertId();
        }

        // Cek atau tambah periode
        $stmt = $pdo->prepare("SELECT id FROM periods WHERE period_name = ?");
        $stmt->execute([$period_name]);
        $period = $stmt->fetch();
        if ($period) {
            $period_id = $period['id'];
        } else {
            $stmt = $pdo->prepare("INSERT INTO periods (period_name) VALUES (?)");
            $stmt->execute([$period_name]);
            $period_id = $pdo->lastInsertId();
        }

        // Update item
        $stmt = $pdo->prepare("UPDATE items SET name = ?, origin_id = ?, period_id = ? WHERE id = ?");
        $result = $stmt->execute([$name, $origin_id, $period_id, $id]);

        if ($result) {
            // Update atau insert deskripsi
            $stmtCheck = $pdo->prepare("SELECT id FROM description WHERE item_id = ?");
            $stmtCheck->execute([$id]);
            $descExists = $stmtCheck->fetch();

            if ($descExists) {
                $stmtUpdate = $pdo->prepare("UPDATE description SET content = ? WHERE item_id = ?");
                $stmtUpdate->execute([$description, $id]);
            } else {
                $stmtInsert = $pdo->prepare("INSERT INTO description (item_id, content) VALUES (?, ?)");
                $stmtInsert->execute([$id, $description]);
            }

            $success = "Data berhasil diperbarui.";
            $item['name'] = $name;
        } else {
            $error = "Gagal memperbarui data.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Edit Lukisan Antik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-image: url('img/Museum.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            min-height: 100vh;
        }

        .container {
            background-color: rgba(41, 41, 41, 0.7);
            padding: 30px;
            border-radius: 10px;
            margin-top: 30px;
        }
        .table {
            background-color: white;
            color: black;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="index.php">Info Lukisan Antik</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Daftar Benda</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                <li class="nav-item"><a href="logout.php" class="nav-link">Logout (<?= htmlspecialchars($_SESSION['username']) ?>)</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h2 class="text-white">Edit Lukisan Antik</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label for="origin_name" class="text-white">Asal Lukisan</label>
            <input type="text" name="origin_name" id="origin_name" class="form-control" required value="<?= htmlspecialchars($origin_name) ?>">
        </div>

        <div class="mb-3">
            <label for="period_name" class="text-white">Periode / Abad</label>
            <input type="text" name="period_name" id="period_name" class="form-control" required value="<?= htmlspecialchars($period_name) ?>">
        </div>

        <div class="mb-3">
            <label for="description" class="text-white">Deskripsi (opsional)</label>
            <textarea name="description" id="description" rows="4" class="form-control"><?= htmlspecialchars($description) ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
