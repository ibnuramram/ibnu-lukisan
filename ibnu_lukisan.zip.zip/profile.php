<?php
// profile.php
session_start();
include "config.php";

// cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Ambil data user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    // User tidak ditemukan, logout
    header("Location: logout.php");
    exit;
}

// Jika form update password disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Cek password lama benar
    if (!password_verify($current_password, $user['password'])) {
        $error = "Password lama salah.";
    } elseif (strlen($new_password) < 6) {
        $error = "Password baru minimal 6 karakter.";
    } elseif ($new_password !== $confirm_password) {
        $error = "Konfirmasi password tidak cocok.";
    } else {
        // Update password baru (hash)
        $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$new_password_hash, $user_id]);
        $success = "Password berhasil diubah.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Profil User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
         body {
            background-image: url('img/l.jpg'); /* Ganti dengan path ke gambar kamu */
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            min-height: 100vh;
        }

        .container {
            background-color: rgba(41, 41, 41, 0.7); /* transparansi untuk konten */
            padding: 20px;
            border-radius: 15px;
            margin-top: 30px;
        }

        .table {
            background-color: white;
            color: black;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="index.php">Info Lukisan Antik</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Daftar Lukisan</a></li>
                <li class="nav-item"><a href="logout.php" class="nav-link">Logout (<?= htmlspecialchars($_SESSION['username']) ?>)</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4" style="max-width: 500px;">
    <h2P class="text-white">Profile User</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post" action="profile.php">
        <div class="mb-3">
            <label class="text-white">Username</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" disabled />
        </div>
        <div class="mb-3">
            <label class="text-white">Nama Lengkap</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($user['fullname']) ?>" disabled />
        </div>

        <hr>

        <h5 class="text-white">Ubah Password</h5>

        <div class="mb-3">
            <label for="current_password" class="text-white">Password Lama</label>
            <input type="password" name="current_password" id="current_password" required class="form-control" />
        </div>
        <div class="mb-3">
            <label for="new_password" class="text-white">Password Baru</label>
            <input type="password" name="new_password" id="new_password" required class="form-control" />
        </div>
        <div class="mb-3">
            <label for="confirm_password" class="text-white">Konfirmasi Password Baru</label>
            <input type="password" name="confirm_password" id="confirm_password" required class="form-control" />
        </div>

        <button type="submit" class="btn btn-primary">Ubah Password</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
