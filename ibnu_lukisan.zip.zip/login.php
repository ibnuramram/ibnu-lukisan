<?php
// login.php
session_start(); // mulai session

include "config.php"; // include koneksi database

// jika user sudah login, langsung redirect ke index.php
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// jika form login disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // ambil data username dan password dari form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // ambil user dari tabel users berdasarkan username
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    // cek user ditemukan dan password cocok (disini asumsikan password hash menggunakan password_hash)
    if ($user && password_verify($password, $user['password'])) {
        // simpan data user di session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];

        // redirect ke halaman utama
        header("Location: index.php");
        exit;
    } else {
        $error = "Username atau password salah!";
    }
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login - Info Lukisan Antik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
     <style>
         body {
            background-image: url('img/login.jpg'); /* Ganti dengan path ke gambar kamu */
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            min-height: 100vh;
        }

        .container {
            background-color: rgba(41, 41, 41, 0.7); /* transparansi untuk konten */
            padding: 20px;
            border-radius: 15px;
            margin-top: 30px;
        }

        .table {
            background-color: white;
            color: black; 
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }
    </style>  
</head>
<body class="bg-light">
<div class="container mt-5" style="max-width: 400px;">
    <h3 class="text-white">Login Info Lukisan Antik</h3>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" action="login.php">
        <div class="mb-3">
            <label for="username" class="text-white">Username</label>
            <input type="text" name="username" id="username" required class="form-control" />
        </div>
        <div class="mb-3">
            <label for="password" class="text-white">Password</label>
            <input type="password" name="password" id="password" required class="form-control" />
        </div>
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
