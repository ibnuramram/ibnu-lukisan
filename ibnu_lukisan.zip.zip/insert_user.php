<?php
// insert_admin.php
include "config.php";

try {
    // Username yang akan dibuat
    $username = "admin";
    $fullname = "Administrator";

    // Cek apakah user sudah ada
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $exists = $stmt->fetchColumn();

    if ($exists) {
        echo "⚠️ User '$username' sudah ada di database.";
        exit;
    }

    // Hash password
    $password = password_hash("12345", PASSWORD_DEFAULT); // ← aman

    // Insert user baru
    $stmt = $pdo->prepare("INSERT INTO users (username, password, fullname) VALUES (?, ?, ?)");
    $stmt->execute([$username, $password, $fullname]);

    echo "✅ User '$username' berhasil ditambahkan dengan password: 12345 (sudah di-hash)";
} catch (PDOException $e) {
    echo "❌ Gagal menambahkan user: " . $e->getMessage();
}
?>
