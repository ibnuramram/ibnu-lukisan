<?php
// config.php
// konfigurasi koneksi database MySQL menggunakan PDO

// set host, nama database, username, dan password
$host = "localhost";
$dbname = "antique_db";
$username = "root";
$password = "";

// buat koneksi PDO dan set error mode ke exception
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // jika koneksi gagal, tampilkan error
    die("Koneksi database gagal: " . $e->getMessage());
}
?>
