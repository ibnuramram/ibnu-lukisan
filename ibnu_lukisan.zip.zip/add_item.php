<?php
session_start();
include "config.php";

// Cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

// Proses submit form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $origin_name = trim($_POST['origin_name']);
    $period_name = trim($_POST['period_name']);
    $description = trim($_POST['description']);

    if ($name == '' || $origin_name == '' || $period_name == '') {
        $error = "Nama, Asal, dan Periode wajib diisi!";
    } else {
        // Cek atau insert origin
        $stmt = $pdo->prepare("SELECT id FROM origins WHERE origin_name = ?");
        $stmt->execute([$origin_name]);
        $origin = $stmt->fetch();
        if ($origin) {
            $origin_id = $origin['id'];
        } else {
            $stmt = $pdo->prepare("INSERT INTO origins (origin_name) VALUES (?)");
            $stmt->execute([$origin_name]);
            $origin_id = $pdo->lastInsertId();
        }

        // Cek atau insert period
        $stmt = $pdo->prepare("SELECT id FROM periods WHERE period_name = ?");
        $stmt->execute([$period_name]);
        $period = $stmt->fetch();
        if ($period) {
            $period_id = $period['id'];
        } else {
            $stmt = $pdo->prepare("INSERT INTO periods (period_name) VALUES (?)");
            $stmt->execute([$period_name]);
            $period_id = $pdo->lastInsertId();
        }

        // Insert item tanpa kategori
        $stmt = $pdo->prepare("INSERT INTO items (name, origin_id, period_id, description) VALUES (?, ?, ?, ?)");
        $result = $stmt->execute([$name, $origin_id, $period_id, $description]);

        if ($result) {
            $success = "Data lukisan antik berhasil ditambahkan.";
            $name = $origin_name = $period_name = $description = '';
        } else {
            $error = "Gagal menyimpan data.";
        }
    }
}
?>

<!-- HTML -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tambah Lukisan Antik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-image: url('img/tambah.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            min-height: 100vh;
        }

        .container {
            background-color: rgba(41, 41, 41, 0.7);
            padding: 20px;
            border-radius: 15px;
            margin-top: 30px;
            box-shadow: 0 0 15px rgba(255, 252, 252, 0.2);
        }

        .table {
            background-color: white;
            color: black;
        }

        .table thead {
            background-color:rgb(150, 155, 161);
            color: white;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="index.php">Info Lukisan Antik</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Daftar Lukisan</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                <li class="nav-item"><a href="logout.php" class="nav-link">Logout (<?= htmlspecialchars($_SESSION['username']) ?>)</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
    <h2 class="text-white">Tambah Lukisan Antik</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post" action="add_item.php">
        <div class="mb-3">
            <label for="name" class="text-white">Nama Lukisan</label>
            <input type="text" name="name" id="name" required class="form-control" value="<?= htmlspecialchars($name ?? '') ?>">
        </div>

        <div class="mb-3">
            <label for="origin_name" class="text-white">Asal Lukisan</label>
            <input type="text" name="origin_name" id="origin_name" required class="form-control" value="<?= htmlspecialchars($origin_name ?? '') ?>">
        </div>

        <div class="mb-3">
            <label for="period_name" class="text-white">Periode / Abad</label>
            <input type="text" name="period_name" id="period_name" required class="form-control" value="<?= htmlspecialchars($period_name ?? '') ?>">
        </div>

        <div class="mb-3">
            <label for="description" class="text-white">Deskripsi (opsional)</label>
            <textarea name="description" id="description" rows="4" class="form-control"><?= htmlspecialchars($description ?? '') ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
