<?php
// index.php
session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : "";

$sql = "SELECT items.id, items.name, 
               origins.origin_name, 
               periods.period_name, 
               items.description AS description_text
        FROM items
        JOIN origins ON items.origin_id = origins.id
        JOIN periods ON items.period_id = periods.id";

if ($keyword) {
    $sql .= " WHERE items.name LIKE :keyword";
}

$stmt = $pdo->prepare($sql);
if ($keyword) {
    $stmt->execute(['keyword' => "%$keyword%"]);
} else {
    $stmt->execute();
}

$items = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Daftar Lukisan Antik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <style>
         body {
            background-image: url('img/login.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            min-height: 100vh;
        }

        .container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 15px;
            margin-top: 30px;
        }

        .table {
            background-color: white;
            color: black;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="index.php">Info Lukisan Antik</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="add_item.php">Tambah Lukisan</a></li>
                <li class="nav-item"><a class="nav-link" href="profile.php">Profil</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout (<?= htmlspecialchars($_SESSION['username']) ?>)</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
    <h2 class="text-white">Daftar Lukisan Antik</h2>

    <form class="d-flex mb-3" method="get" action="index.php" role="search">
        <input class="form-control me-2" type="search" placeholder="Cari benda antik..." name="keyword" value="<?= htmlspecialchars($keyword) ?>">
        <button class="btn btn-outline-light" type="submit">Cari</button>
    </form>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Nama Lukisan</th>
                <th>Asal</th>
                <th>Tahun / Abad</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($items) > 0): ?>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['name']) ?></td>
                        <td><?= htmlspecialchars($item['origin_name']) ?></td>
                        <td><?= htmlspecialchars($item['period_name']) ?></td>
                        <td><?= htmlspecialchars($item['description_text'] ?? '-') ?></td>
                        <td>
                            <a href="edit_item.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="delete_item.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin hapus data?')">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center">Tidak ada data lukisan antik.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
