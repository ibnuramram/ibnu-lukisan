<?php
// users.php
session_start();
include "config.php";

// cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Optional: batasi hanya user tertentu bisa akses ini (misal username 'admin')
if ($_SESSION['username'] !== 'admin') {
    die("Anda tidak memiliki akses ke halaman ini.");
}

$action = $_GET['action'] ?? '';
$error = '';
$success = '';

// Fungsi untuk ambil semua user
function getAllUsers($pdo) {
    $stmt = $pdo->query("SELECT id, username, fullname FROM users ORDER BY username ASC");
    return $stmt->fetchAll();
}

// Tambah user baru
if ($action == 'add' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $fullname = trim($_POST['fullname']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if ($username == '' || $fullname == '' || $password == '' || $confirm == '') {
        $error = "Semua field wajib diisi!";
    } elseif ($password !== $confirm) {
        $error = "Password dan konfirmasi tidak cocok!";
    } else {
        // Cek username sudah ada
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = "Username sudah digunakan.";
        } else {
            // Insert user baru
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, fullname) VALUES (?, ?, ?)");
            if ($stmt->execute([$username, $hash, $fullname])) {
                $success = "User berhasil ditambahkan.";
            } else {
                $error = "Gagal menambahkan user.";
            }
        }
    }
}

// Hapus user
if ($action == 'delete' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int)$_GET['id'];
    if ($id == $_SESSION['user_id']) {
        $error = "Anda tidak bisa menghapus akun sendiri.";
    } else {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = "User berhasil dihapus.";
        } else {
            $error = "Gagal menghapus user.";
        }
    }
}

// Ambil semua user untuk ditampilkan
$users = getAllUsers($pdo);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Kelola User Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
        <style>
         body {
            background-image: url('img/l.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            min-height: 100vh;
        }

        .container {
            background-color: rgba(41, 41, 41, 0.7);
            padding: 20px;
            border-radius: 15px;
            margin-top: 30px;
        }

        .table {
            background-color: white;
            color: black;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="index.php">Info Lukisan Antik</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Daftar Lukisan</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                <li class="nav-item"><a href="logout.php" class="nav-link">Logout (<?= htmlspecialchars($_SESSION['username']) ?>)</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4" style="max-width: 800px;">
    <h2 class="text-white">Kelola User Admin</h2>

    <!-- Pesan error -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Pesan sukses -->
    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Form tambah user -->
    <?php if ($action == 'add'): ?>
        <a href="users.php" class="btn btn-secondary mb-3">Kembali</a>
        <form method="post" action="users.php?action=add" style="max-width: 400px;">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" name="username" id="username" required class="form-control" />
            </div>
            <div class="mb-3">
                <label for="fullname" class="form-label">Nama Lengkap</label>
                <input type="text" name="fullname" id="fullname" required class="form-control" />
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" required class="form-control" />
            </div>
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                <input type="password" name="confirm_password" id="confirm_password" required class="form-control" />
            </div>
            <button type="submit" class="btn btn-primary">Tambah User</button>
        </form>

    <?php else: ?>
        <a href="users.php?action=add" class="btn btn-success mb-3">Tambah User Baru</a>
        <table class="table table-bordered">
            <thead class="table-primary">
                <tr>
                    <th>Username</th>
                    <th>Nama Lengkap</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td><?= htmlspecialchars($u['username']) ?></td>
                        <td><?= htmlspecialchars($u['fullname']) ?></td>
                        <td>
                            <?php if ($u['id'] != $_SESSION['user_id']): ?>
                                <a href="users.php?action=delete&id=<?= $u['id'] ?>" 
                                   onclick="return confirm('Yakin ingin menghapus user ini?')" class="btn btn-sm btn-danger">Hapus</a>
                            <?php else: ?>
                                <em>Akun Anda</em>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
